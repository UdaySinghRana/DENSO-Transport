import React from 'react'
import '../Components/Main3.css'
import img2 from '../images/banner-bg.png'

const Main3 = () => {
    return (
        <div>
            <div className="latest" id="nav-news">
                <h1>LATEST NEWS AND EVENTS<div className="underline" /></h1>
                <div className="box">
                    <div className="latest-div-components">
                        <img src={img2} alt="" className="image2"/>
                        <div className="icon" id="icon1">
                            <p>
                                01
                                <br />
                                Sep
                            </p>
                        </div>
                        <h1>LIBERALISATION OF AIR CARGO INDUSTRY</h1>
                        <p id="latest-p">
                            ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. ion ullamco laboris nisi ut
                            aliquip ex ea commodo consequat. Duis aute
                        </p>
                    </div>
                    <div className="latest-div-components">
                    <img src={img2} alt="" className="image2"/>
                        <div className="icon" id="icon2">
                            <p>
                                02
                                <br />
                                Sep
                            </p>
                        </div>
                        <h1>NEW WAREHOUSE NOW OPERATIONAL</h1>
                        <p id="latest-p">
                            ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. ion ullamco laboris nisi ut
                            aliquip ex ea commodo consequat. Duis aute
                        </p>
                    </div>
                    <div className="latest-div-components">
                    <img src={img2} alt="" className="image2"/>
                        <div className="icon" id="icon3">
                            <p>
                                03
                                <br />
                                Sep
                            </p>
                        </div>
                        <h1>NEW TRUCKS ARRIVING SOON</h1>
                        <p id="latest-p">
                            ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. ion ullamco laboris nisi ut
                            aliquip ex ea commodo consequat. Duis aute
                        </p>
                    </div>
                </div>
                <button className="buttonn">Read More</button>
            </div>

        </div>
    )
}

export default Main3
