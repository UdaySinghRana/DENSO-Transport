import React from 'react'
import '../Components/Main2.css'
import img1 from '../images/francois-van-ACzGBDIJbdY-unsplash.png'
import back from '../images/img-1.png'

const Main2 = () => {
    return (
        <div>
            <>
                <div className="welcome">
                    <h1>Welcome to Denso Transport</h1>
                    <div className="underline" />
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                        velit esse cillum
                    </p>
                </div>
                {/* Services */}
                <div className="services">
                    <h1 className="headings">Services<div className="underline" /></h1>

                    <p className="paras">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna
                    </p>
                    <div className="servicesicons">
                        <div className="icons">
                            <p>FLY ANYWHERE</p>
                        </div>
                        <div className="icons">
                            <p>Cargo service</p>
                        </div>
                        <div className="icons">
                            <p>COURIER SERVICES</p>
                        </div>
                        <div className="icons">
                            <p>BOX STORAGE</p>
                        </div>
                        <div className="icons">
                            <p>100% safe</p>
                        </div>
                    </div>
                    <button className="buttonn">READ MORE</button>
                </div>
                {/* About */}
                <div className="about" id="nav-about">
                    <div className="about-div">
                        <h1>About transport<div className="underline" /></h1>

                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                            veniam, quis nostrud exercitation ullamco laboris
                        </p>
                        <button className="buttonn">READ MORE</button>
                    </div>
                    <div className="aboutimg">
                        <img id="" src={img1}/>

                    </div>
                </div>
            </>

        </div>
    )
}

export default Main2
