import React from 'react'
import '../Components/Main.css'
import logo from '../images/logo.png'
import lens from '../images/search.png'
const Main = () => {
    return (
        <div>
            <div className="navbar">
                <nav>
                    <div className="set" id="air-freight-div">
                        <a href="#">
                            <img id="air-freight" src={logo} alt="" />
                        </a>
                    </div>
                    <div className="set" id="nav-contact1">
                        <img src="images/telephone-symbol-button.png" alt="" />
                        <p>Call Us : +01 1234567890</p>
                    </div>
                    <div className="set" id="nav-contact2">
                        <img src="images/email.png" alt="" />
                        <p>demo@gmail.com</p>
                    </div>
                    <div className="nav-search">
                        <input type="text" placeholder="Search" name="" id="" />
                        <button className="lens">
                            <img src={lens} alt="" />
                        </button>
                    </div>
                </nav>
                <div className="menu">
                    <ul>
                        <a href="#">
                            <li className="list">HOME</li>
                        </a>
                        <a href="#nav-about">
                            <li className="list">ABOUT</li>
                        </a>
                        <a href="#">
                            <li className="list">TRANSPORT</li>
                        </a>
                        <a href="#nav-news">
                            <li className="list">NEWS</li>
                        </a>
                        <a href="#nav-clients">
                            <li className="list">CLIENTS</li>
                        </a>
                        <a href="#request">
                            <li className="list">CONTACT US</li>
                        </a>
                        <a href="#">
                            <li className="list">LOGIN</li>
                        </a>
                        <a href="#">
                            <li className="list">REGISTER</li>
                        </a>
                    </ul>
                </div>
            </div>

        </div>
    )
}

export default Main
