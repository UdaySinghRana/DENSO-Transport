import React from 'react'
import '../Components/Footer.css'

const Footer = () => {
    return (
        <div>
            <>
                <footer>
                    <div className="denso">
                        <a href="#" className="footer-logo">
                            <img src="images/footer-logo.png" alt="" />
                        </a>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                        </p>
                        <div className="icons">
                            <a href="#">
                                <img src="images/fb-icon.png" alt="" />
                            </a>
                            <a href="#">
                                <img src="images/twitter-icon.png" alt="" />
                            </a>
                            <a href="#">
                                <img src="images/linkedin-icon.png" alt="" />
                            </a>
                            <a href="#">
                                <img src="images/instagram-icon.png" alt="" />
                            </a>
                        </div>
                    </div>
                    <div className="line" />
                    <div className="information">
                        <div>
                            <div className="heading">information</div>
                            <div className="paragraph">
                                There are many variations of passages of Lorem Ipsum available, but
                                the majority
                            </div>
                        </div>
                        <div>
                            <div className="heading">information</div>
                            <div className="paragraph">
                                There are many variations of passages of Lorem Ipsum available, but
                                the majority
                            </div>
                        </div>
                        <div>
                            <div className="heading">information</div>
                            <div className="paragraph">
                                There are many variations of passages of Lorem Ipsum available, but
                                the majority
                            </div>
                        </div>
                    </div>
                </footer>
                {/* Rights */}
                <div className="rights">
                    <p>© 2019 All Rights Reserved. Free html Templates</p>
                </div>
            </>

        </div>
    )
}

export default Footer
