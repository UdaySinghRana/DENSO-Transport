import React from 'react'
import '../Components/Main4.css'

const Main4 = () => {
    return (
        <div>
            <>
                <div className="testimonial" id="nav-clients">
                    <h1>Testimonial<div className="underline" /></h1>
                    
                    <div className="testimonial-scroll">
                        <div className="testimonial-scroll-first-box">
                            <img src="images/keyboard-right-arrow-button (1) copy.png" alt="" />
                        </div>
                        <div className="testimonial-scroll-component">
                            <div className="scroll-icon">
                                <img src="images/img-4.png" alt="" />
                                <p>Consectetur</p>
                            </div>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                                minim veniam, quis
                            </p>
                        </div>
                        <div className="testimonial-scroll-component">
                            <div className="scroll-icon">
                                <img src="images/img-4.png" alt="" />
                                <p>Consectetur</p>
                            </div>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                                minim veniam, quis
                            </p>
                        </div>
                        <div className="testimonial-scroll-second-box">
                            <img src="images/keyboard-right-arrow-button (1).png" alt="" />
                        </div>
                    </div>
                </div>
                {/* Request */}
                <div id="request">
                    <h1>Request a call back</h1>
                    <div className="underline" />
                    <input type="text" name="" id="" placeholder="Name" />
                    <input type="email" name="" id="" placeholder="Email" />
                    <input type="tel" name="" id="" placeholder="Phone Number" />
                    <textarea name="" id="" rows={5} placeholder="Message" defaultValue={""} />
                    <button>Send</button>
                </div>
                {/* Call */}
                <div className="call">
                    <div>
                        <img src="images/call-icon1.png" alt="" />
                        <p>Call Now +01 123467890</p>
                    </div>
                    <div>
                        <img src="images/map-icon.png" alt="" />
                        <p>Location</p>
                    </div>
                    <div>
                        <img src="images/mail-icon1.png" alt="" />
                        <p>demo@gmail.com</p>
                    </div>
                </div>
            </>

        </div>
    )
}

export default Main4
