import React from 'react'
import '../Components/Main1.css'

const Main1 = () => {
    return (
        <div>
            <div className="main">
                <p className="date">01/02</p>
                <div className="head-main-head">
                    <div className="main-head">
                        <div className="line" />
                        <h1>
                            Autos &amp; <br />
                            TRANSPORTATION
                        </h1>
                    </div>
                    <p className="main-p">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                        veniam, quis nostrud exercitation ullamco laboris
                    </p>
                    <a href="#request">
                        <button className="contact">CONTACT US</button>{" "}
                    </a>
                </div>
                <div className="main-form">
                    <p>Professional Services</p>
                    <h2>Get your transport quote</h2>
                    <input type="text" placeholder="Location" />
                    <input type="text" placeholder="To Destination" />
                    <input type="text" placeholder="Email" />
                    <input type="text" placeholder="Contact Number" />
                    <button id="quote">Get Now quote</button>
                </div>
                <div className="arrow">
                    <button className="arrow-first">
                        <img src="images/keyboard-right-arrow-button (1).png" alt="" />
                    </button>
                    <button className="arrow-second">
                        <img src="images/keyboard-right-arrow-button (1) copy.png" alt="" />
                    </button>
                </div>
            </div>

        </div>
    )
}

export default Main1
