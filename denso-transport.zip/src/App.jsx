import React from 'react'
import Main from './Components/Main'
import Main1 from './Components/Main1'
import Main2 from './Components/Main2'
import Main3 from './Components/Main3'
import Main4 from './Components/Main4'
import Footer from './Components/Footer'
import back from '../src//images/img-1.png'
import './App.css'
const App = () => {
  return (
    <div>
      
      <Main></Main>
      <div className='back111'>
        <img className="back11" src={back}></img>
        <Main1></Main1>
      </div>
      
      <Main2></Main2>
      <Main3></Main3>
      <Main4></Main4>
      <Footer></Footer>
    </div>
  )
}

export default App
